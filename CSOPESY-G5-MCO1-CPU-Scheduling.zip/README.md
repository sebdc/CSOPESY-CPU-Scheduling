# CSOPESY-CPU-Scheduling
 
1 - Add the test case to the input folder
2 - Go to app.py and change the 'fileInputName' to the txt file name
3 - Run app.py